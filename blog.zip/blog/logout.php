<?php require_once("includes/session.php"); ?>
<?php require_once("includes/functions.php"); ?>

<?php

	$_SESSION["user_id"] = null;
	$_SESSION["user_name"] = null;
	$_SESSION["user_email"] = null;

	unset($_SESSION);
	redirect_to("index.php");
?>

