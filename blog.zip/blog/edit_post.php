<?php include_once("includes/session.php") ?>
<?php include_once("includes/db_connection.php")?>
<?php require_once("includes/functions.php"); ?>
<?php require_once("includes/validation_functions.php"); ?>

<?php if(!has_logged_in()){ redirect_to("index.php"); } ?>

<?php  

$post_id = (int)$_GET['id'];

$post = get_post_by_id($post_id);

if(!$post){
    $_SESSION['message'] = "somthing went to wrong";
    redirect_to("my_post.php");
}

if(isset($_POST['submit'])){

$user_id = (int)$_SESSION['user_id'];
$title =  mysql_prep($_POST["title"]);
$contant =  mysql_prep($_POST["contant"]);

$required_fields = array("title", "contant");
validate_presences($required_fields);




if (empty($errors)) {
  //password hashing  

  $query  = "UPDATE blog_post SET ";
  $query .= "user_id = '{$user_id}', ";
  $query .= "title = '{$title}', ";
  $query .= "contant = '{$contant}' ";
  $query .= "WHERE id = {$post_id} ";
  $query .= "LIMIT 1";
  $result = mysqli_query($connection, $query);

  if ($result) {
    // Success
    $_SESSION["message"] = "blog post Edited .";
    redirect_to("my_post.php");
  } else {
    // Failure
    $_SESSION["message"] = "Post editing failed.";
    
    redirect_to("my_post.php");

  }
}
  
}

?>

<?php require_once('includes/layouts/header.php') ?>
<?php echo message(); ?>
<?php echo form_errors($errors); ?>
<form action="edit_post.php?id=<?php echo $post_id ?>" method="post">
  <div class="field">
    <label class="label">Post Header</label>
    <div class="control">
      <input class="input" type="text" placeholder="Post Header" name="title" value="<?php echo htmlentities($post['title']) ?>">
    </div>
  </div>


  <div class="field">
    <label class="label">Post Contant</label>
    <div class="control">
      <textarea class="textarea" placeholder="Post Contant" name="contant"><?php echo htmlentities($post['contant']) ?></textarea>
    </div>
  </div>


  <div class="field is-grouped">
    <div class="control">
      <button class="button is-link" name="submit">Save</button>
    </div>
  </div>
</form>
<?php require_once('includes/layouts/footer.php') ?>