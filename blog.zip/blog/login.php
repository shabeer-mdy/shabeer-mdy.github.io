<?php include_once("includes/session.php") ?>
<?php include_once("includes/db_connection.php")?>
<?php require_once("includes/functions.php"); ?>
<?php require_once("includes/validation_functions.php"); ?>

<?php
$email = "";

if (isset($_POST['submit'])) {
  // Process the form
  
  // validations
  $required_fields = array("email", "password");
  validate_presences($required_fields);
  
  if (empty($errors)) {
    // Attempt Login

		$email = $_POST["email"];
		$password = $_POST["password"];
		
    $found_user = attempt_login($email, $password);
    

    if ($found_user) {
      // Success
      $_SESSION["user_id"] = $found_user["id"];
      $_SESSION["user_name"] = $found_user["name"];
      $_SESSION["user_email"] = $found_user["email"];
      
      redirect_to("index.php");

    } else {
      // Failure
      $_SESSION["message"] = "email/password not found.";
    }
  }
} 

?>

<?php require_once('includes/layouts/header.php') ?>
<?php echo message(); ?>
<?php echo form_errors($errors); ?>
<form action="login.php" method="post">
  <div class="field">
    <p class="control has-icons-left has-icons-right">
      <input class="input" type="email" placeholder="Email" name="email">
      <span class="icon is-small is-left">
        <i class="fas fa-envelope"></i>
      </span>
      <span class="icon is-small is-right">
        <i class="fas fa-check"></i>
      </span>
    </p>
  </div>
  <div class="field">
    <p class="control has-icons-left">
      <input class="input" type="password" placeholder="Password" name="password">
      <span class="icon is-small is-left">
        <i class="fas fa-lock"></i>
      </span>
    </p>
  </div>
  <div class="field">
    <p class="control">
      <button class="button is-success" name="submit">
        Login
      </button>
    </p>
  </div>
</form>

<?php require_once('includes/layouts/footer.php') ?>