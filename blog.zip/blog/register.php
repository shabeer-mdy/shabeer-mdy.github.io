<?php include_once("includes/session.php") ?>
<?php include_once("includes/db_connection.php")?>
<?php require_once("includes/functions.php"); ?>
<?php require_once("includes/validation_functions.php"); ?>

<?php  

  if(isset($_POST['submit'])){

	$name = mysql_prep($_POST["name"]);
  $email =  mysql_prep($_POST["email"]);
  $password = mysql_prep($_POST["password"]);
  $cpassword = mysql_prep($_POST["confirm_password"]);

  $required_fields = array("name", "email", "password", "confirm_password");
  validate_presences($required_fields);


  validate_confirm_password($password, $cpassword);
	
	
	if (empty($errors)) {
    //password hashing  
    $hashed_password = password_encrypt($password);


    $query  = "INSERT INTO user (";
    $query .= "  name, email, password";
    $query .= ") VALUES (";
    $query .= "  '{$name}', '{$email}', '{$hashed_password}'";
    $query .= ")";
    $result = mysqli_query($connection, $query);
  
    if ($result) {
      // Success
      $_SESSION["message"] = "Successfully registered.";

      $user = getUserByEmail($email);
  
      $_SESSION["user_id"] = $user["id"];
      $_SESSION["user_name"] = $user["name"];
      $_SESSION["user_email"] = $user["email"];
      redirect_to("index.php");
    } else {
      // Failure
      $_SESSION["message"] = "Subject creation failed.";

      print_r(mysqli_error_list($connection));
    }
	}
		
}

?>



<?php require_once('includes/layouts/header.php') ?>

    <?php echo message(); ?>
    <?php echo form_errors($errors); ?>

<nav class="breadcrumb" aria-label="breadcrumbs">
  <ul>
    <li><a href="#">BlogApp</a></li>
    <li><a href="#">Register</a></li>
  </ul>
</nav>

<form action="register.php" method="post">

  <div class="field">
    <p class="control has-icons-left has-icons-right">
      <input class="input" type="text" placeholder="Name" name="name">
      <span class="icon is-small is-left">
        <i class="fas fa-user"></i>
      </span>
    </p>
  </div>

  <div class="field">
    <p class="control has-icons-left has-icons-right">
      <input class="input" type="email" placeholder="Email" name="email">
      <span class="icon is-small is-left">
        <i class="fas fa-envelope"></i>
      </span>
    </p>
  </div>

  <div class="field">
    <p class="control has-icons-left">
      <input class="input" type="password" placeholder="Password" name="password">
      <span class="icon is-small is-left">
        <i class="fas fa-lock"></i>
      </span>
    </p>
  </div>

  <div class="field">
    <p class="control has-icons-left">
      <input class="input" type="password" placeholder=" Confirm Password" name="confirm_password">
      <span class="icon is-small is-left">
        <i class="fas fa-lock"></i>
      </span>
    </p>
  </div>

  <div class="field">
    <p class="control">
      <button class="button is-success" name="submit">
        Register
      </button>
    </p>
  </div>
</form>

<?php require_once('includes/layouts/footer.php') ?>