<?php require_once('includes/session.php') ?>
<?php require_once('includes/db_connection.php') ?>
<?php require_once('includes/functions.php') ?>
<?php var_dump($_SESSION); ?>

<?php 
if(!has_logged_in()){
    redirect_to('login.php');
}
$post_set = get_post(); 
?>

<?php require_once('includes/layouts/header.php') ?>
<?php echo message(); ?>
<?php while($post = mysqli_fetch_assoc($post_set)){ ?>
<div class="column">
<div class="card">
  <header class="card-header">
    <p class="card-header-title">
      <?php  echo htmlentities($post['title']); ?>
    </p>
    <a href="#" class="card-header-icon" aria-label="more options">
      <span class="icon">
        <i class="fas fa-angle-down" aria-hidden="true"></i>
      </span>
    </a>
  </header>
  <div class="card-content">
    <div class="content">
      <?php  echo htmlentities($post['contant']); ?>
      <br>
      <a href="#">@<?php echo htmlentities($post['name']); ?></a>
    </div>
  </div>
  </div>
  </div>
  <?php } ?>
  <?php if(mysqli_affected_rows($connection) == 0){ ?>
    <div class="column">
<div class="card">
  <header class="card-header">
    <p class="card-header-title">
      No Post yet , follow the users
    </p>
  </header>
  </div>
  </div>
  <?php } ?>
<?php require_once('includes/layouts/footer.php'); ?>