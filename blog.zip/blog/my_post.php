<?php require_once('includes/session.php') ?>
<?php require_once('includes/db_connection.php') ?>
<?php require_once('includes/functions.php') ?>
<?php var_dump($_SESSION); ?>

<?php 
if(!has_logged_in()){
    redirect_to('login.php');
}
$post_set = get_all_post_by_user($_SESSION['user_id']); 

?>

<?php require_once('includes/layouts/header.php') ?>
<?php echo message(); ?>
<?php while($post = mysqli_fetch_assoc($post_set)){ ?>
<div class="column">
<div class="card">
  <header class="card-header">
    <p class="card-header-title">
      <?php  echo htmlentities($post['title']); ?>
    </p>
    <a href="#" class="card-header-icon" aria-label="more options">
      <span class="icon">
        <i class="fas fa-angle-down" aria-hidden="true"></i>
      </span>
    </a>
  </header>
  <div class="card-content">
    <div class="content">
      <?php  echo htmlentities($post['contant']); ?>
      <br>
    </div>
  </div>
  <?php if(has_logged_in()){ ?>
    <?php if($post['user_id'] == $_SESSION['user_id']){ ?>
    <footer class="card-footer">
      <a href="edit_post.php?id=<?php echo $post['id'] ?>" class="card-footer-item">Edit</a>
      <a href="delete_post.php?id=<?php echo $post['id'] ?>" class="card-footer-item" onclick = "confirm('are you sure?');">Delete</a>
    </footer>

  <?php }
  }?>
  </div>
  </div>
  <?php } ?>
  <?php if(mysqli_affected_rows($connection) == 0){ ?>
    <div class="column">
<div class="card">
  <header class="card-header">
    <p class="card-header-title">
      No Post yet , Create some Post
    </p>
  </header>
  </div>
  </div>
  <?php } ?>
<?php require_once('includes/layouts/footer.php'); ?>