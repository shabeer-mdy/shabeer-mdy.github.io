<?php include_once("includes/session.php") ?>
<?php include_once("includes/db_connection.php")?>
<?php require_once("includes/functions.php"); ?>

<?php 

  //get all users
  $user_set = get_all_users();

?>

<?php require_once('includes/layouts/header.php') ?>
<?php echo message(); ?>
<div class="column">
<?php while($user = mysqli_fetch_assoc($user_set)){ ?>
  <div class="column">
    <div class="card">
      <div class="card-content">
        <div class="media">
          <div class="media-left">
            
          </div>
          <div class="">
            <p class="title is-4"><?php echo htmlentities($user['name']); ?></p>
            <p class="subtitle is-6"><?php echo htmlentities($user['email']); ?></p>
          </div>
        </div>
      <footer class="card-footer">
      
      <?php 
        $no_of_post_set = get_no_of_posts();//get no of post
        while($no_of_post = mysqli_fetch_assoc($no_of_post_set)){ 
      ?>
        <?php if( $user['id'] == $no_of_post['id']){ ?>
          <a href="#" class="card-footer-item">Post(<?php echo htmlentities($no_of_post['numberOfPost']) ?>)</a>
          <?php 
            mysqli_free_result($no_of_post_set); 
            break;
          ?> 
        <?php } ?>
      <?php } ?>
        <?php if(has_logged_in()){ ?>
          <?php if($user['id'] != $_SESSION['user_id']){ ?>
            <?php 
            $following = false;
              $follower_set = get_follower_by_user_id($_SESSION['user_id']);
              while($follower = mysqli_fetch_array($follower_set)){

              $following = find_user_wether_is_following($follower, $user['id']);
              
              if($following){ break; }
            ?>
              <?php 
              }
              mysqli_free_result($follower_set); ?>
              <?php if($following){ ?>
                <a href="unfollow.php?user_id=<?php echo htmlentities($user['id']) ?>" class="card-footer-item">unfollow</a>
                <?php }else{ ?>
                <a href="follow.php?user_id=<?php echo htmlentities($user['id']) ?>" class="card-footer-item">follow</a>
              <?php }?>
        <?php } }?>
      </footer>
      </div>
    </div>
  </div>
<?php } ?>
</div>

<?php require_once('includes/layouts/footer.php') ?>