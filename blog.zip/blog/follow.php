<?php require_once('includes/session.php') ?>
<?php require_once('includes/db_connection.php') ?>
<?php require_once('includes/functions.php') ?>

<?php 
    //whethe user not logged in
    if(!has_logged_in()){
        redirect_to("login.php");
    } 
?>

<?php 

    if(isset($_GET['user_id'])){
        $user_id = (int) $_GET['user_id'];
        $follower_id = (int) $_SESSION['user_id'];


        $user = get_user_by_id($user_id);

        if($user){

            $query  = "INSERT INTO folowers ( ";
            $query .= "  user_id, 	folower_id ";
            $query .= ") VALUES ( ";
            $query .= "  '{$user_id}', '{$follower_id}' ";
            $query .= ")";
            $result = mysqli_query($connection, $query);

            if ($result) {
                // Success
                $_SESSION["message"] = "Successfully followed.";
                redirect_to("index.php");
            }else{
                
                $_SESSION["message"] = "somthing went to wrong.";
                redirect_to("show_users.php");
            }

        }else{
            $_SESSION['message'] = 'it is not right ,inform me';
            redirect_to("show_users.php");
        }

    }
?>