<?php

	function redirect_to($new_location) {
	  header("Location: " . $new_location);
	  exit;
	}

	function mysql_prep($string) {
		global $connection;
		
		$escaped_string = mysqli_real_escape_string($connection, $string);
		return $escaped_string;
	}
	
	function confirm_query($result_set) {
		if (!$result_set) {
			die("Database query failed.");
		}
	}

	function form_errors($errors=array()) {
		$output = "";
		if (!empty($errors)) {
		  $output .= "<div class=\"error\">";
		  $output .= "Please fix the following errors:";
		  $output .= "<ul>";
		  foreach ($errors as $key => $error) {
		    $output .= "<li>";
				$output .= htmlentities($error);
				$output .= "</li>";
		  }
		  $output .= "</ul>";
		  $output .= "</div>";
		}
		return $output;
	}
	
	function find_all_subjects($public=true) {
		global $connection;
		
		$query  = "SELECT * ";
		$query .= "FROM subjects ";
		if ($public) {
			$query .= "WHERE visible = 1 ";
		}
		$query .= "ORDER BY position ASC";
		$subject_set = mysqli_query($connection, $query);
		confirm_query($subject_set);
		return $subject_set;
	}
	
	function getUserByEmail($email){
		global $connection;
		
		$query  = "SELECT * ";
		$query .= "FROM user ";
		$query .= "WHERE email = '{$email}' ";

		$result = mysqli_query($connection, $query);
		confirm_query($result);
		return mysqli_fetch_assoc($result);
	}

	function get_post(){
		global $connection;
		  
		$query = "SELECT * ";
		$query .="FROM user JOIN folowers JOIN blog_post ";
		$query .="ON blog_post.user_id = folowers.user_id ";
		$query .="AND folowers.folower_id = {$_SESSION['user_id']} ";
		$query .="AND user.id = blog_post.user_id";
	
		$result = mysqli_query($connection, $query);
		confirm_query($result);
		return $result;
	}

	function get_all_post(){
		global $connection;
		
		$query  = "SELECT * ";
		$query .= "FROM blog_post ";
		$query .= "ORDER BY id ";

		$result = mysqli_query($connection, $query);
		confirm_query($result);
		return $result;
	}

	function get_all_post_by_user($user_id){
		global $connection;
		
		$query  = "SELECT * ";
		$query .= "FROM blog_post ";
		$query .= "WHERE user_id = {$user_id} ";

		$result = mysqli_query($connection, $query);
		confirm_query($result);
		return $result;
	}

	function get_post_by_id($post_id){
		global $connection;
		
		$query  = "SELECT * ";
		$query .= "FROM blog_post ";
		$query .= "WHERE id = {$post_id} ";
		$query .= "AND user_id = {$_SESSION['user_id']} ";

		$result = mysqli_query($connection, $query);
		confirm_query($result);
		return mysqli_fetch_assoc($result);	
	}


	function get_all_users(){
		global $connection;
		
		$query  = "SELECT id, name, email ";
		$query .= "FROM user ";
		$query .= "ORDER BY id ";

		$result = mysqli_query($connection, $query);
		confirm_query($result);
		return $result;
	}

	function get_user_by_id($user_id){
		global $connection;
		
		$query  = "SELECT id, name, email ";
		$query .= "FROM user ";
		$query .= "WHERE id = '{$user_id}' ";

		$result = mysqli_query($connection, $query);
		confirm_query($result);
		return mysqli_fetch_assoc($result);
	}

	function get_no_of_posts(){
		global $connection;

		$query = "SELECT user.id, COUNT(blog_post.user_id) AS numberOfPost ";
		$query .="FROM user JOIN blog_post ";
		$query .="ON user.id = blog_post.user_id ";
		$query .="GROUP BY user.id";


		$result = mysqli_query($connection, $query);
		confirm_query($result);
		return $result;
	}


	function get_follower_by_user_id($user_id){
		global $connection;
		
		$query  = "SELECT * ";
		$query .= "FROM folowers ";
		$query .= "WHERE folower_id = '{$user_id}' ";

		$result = mysqli_query($connection, $query);
		confirm_query($result);
		return $result;
	}


	function find_user_wether_is_following($array, $user_id){
		
		if($user_id == $array['user_id']){
			return true;
		}
	}


	function password_encrypt($password) {
  	$hash_format = "$2y$10$";   // Tells PHP to use Blowfish with a "cost" of 10
	  $salt_length = 22; 					// Blowfish salts should be 22-characters or more
	  $salt = generate_salt($salt_length);
	  $format_and_salt = $hash_format . $salt;
	  $hash = crypt($password, $format_and_salt);
		return $hash;
	}
	
	function generate_salt($length) {
	  // Not 100% unique, not 100% random, but good enough for a salt
	  // MD5 returns 32 characters
	  $unique_random_string = md5(uniqid(mt_rand(), true));
	  
		// Valid characters for a salt are [a-zA-Z0-9./]
	  $base64_string = base64_encode($unique_random_string);
	  
		// But not '+' which is valid in base64 encoding
	  $modified_base64_string = str_replace('+', '.', $base64_string);
	  
		// Truncate string to the correct length
	  $salt = substr($modified_base64_string, 0, $length);
	  
		return $salt;
	}
	
	function password_check($password, $existing_hash) {
		// existing hash contains format and salt at start
	  $hash = crypt($password, $existing_hash);
	  if ($hash === $existing_hash) {
	    return true;
	  } else {
	    return false;
	  }
	}

	function attempt_login($email, $password) {
		$user = getUserByEmail($email);
		if ($user) {
			// found user, now check password
			if (password_check($password, $user["password"])) {
				// password matches
				return $user;
			} else {
				// password does not match
				return false;
			}
		} else {
			// user not found
			return false;
		}
	}

	function logged_in() {
		return isset($_SESSION['user_id']);
	}
	
	function has_logged_in() {
		if (!logged_in()) {
			return false;
		}
		return true;
	}

?>

