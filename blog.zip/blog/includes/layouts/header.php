<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Blog App</title>

    <link rel="stylesheet" href="css/bulma.css">
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    <nav class="navbar is-dark">
    <div class="navbar-brand">
        <a class="navbar-item" href="/">
            <h1 class="logo">Blog App</h1>
        </a>
    </div>

    <div id="navbarExampleTransparentExample" class="navbar-menu">
        <div class="navbar-start">
        <?php if(has_logged_in()){ ?>
        <a class="navbar-item" href="/">
            Home
        </a>
        <a class="navbar-item" href="/create_post.php">
            Create Post
        </a>
        <?php } ?>
        <a class="navbar-item" href="/show_users.php">
            Show Users
        </a>
        </div>

        <div class="navbar-end">
        <?php if(!has_logged_in()){ ?>
        <div class="navbar-item">
            <div class="field is-grouped">
            <p class="control">
                <a href="login.php" class="button is-warning">
                <span class="icon">
                    <i class="fas fa-download"></i>
                </span>
                <span>login</span>
                </a>
            </p>
            </div>
        </div>

        <div class="navbar-item">
            <div class="field is-grouped">
            <p class="control">
                <a href="register.php" class="button is-link">
                <span class="icon">
                    <i class="fas fa-download"></i>
                </span>
                <span>Register</span>
                </a>
            </p>
            </div>
        </div>
        <?php } else {?>
        
        <a class="navbar-item" href="/my_post.php">
           My Post
        </a>

        <div class="navbar-item">
            <div class="field is-grouped">
            <p class="control">
                <a href="logout.php" class="button is-primary">
                <span class="icon">
                    <i class="fas fa-download"></i>
                </span>
                <span>logout</span>
                </a>
            </p>
            </div>
        </div>
        
        <?php } ?>
        </div>
    </div>
    </nav>
    
    <div class="container">