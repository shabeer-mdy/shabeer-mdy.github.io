    </div>
    <footer class="footer">
    <div class="container">
        <div class="content has-text-centered">
        <p>
            <strong>A simple web app for managing blog post developed by Shabeer M</strong>
        </p>
        </div>
    </div>
    </footer>
    <script defer src="js/fontawesome.js"></script>
    </body>
</html>