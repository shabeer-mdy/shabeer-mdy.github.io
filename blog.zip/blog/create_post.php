<?php include_once("includes/session.php") ?>
<?php include_once("includes/db_connection.php")?>
<?php require_once("includes/functions.php"); ?>
<?php require_once("includes/validation_functions.php"); ?>

<?php if(!has_logged_in()){ redirect_to("index.php"); } ?>

<?php  

if(isset($_POST['submit'])){

$user_id = (int)$_SESSION['user_id'];
$title =  mysql_prep($_POST["title"]);
$contant =  mysql_prep($_POST["contant"]);

$required_fields = array("title", "contant");
validate_presences($required_fields);




if (empty($errors)) {
  //password hashing  


  $query  = "INSERT INTO blog_post (";
  $query .= "  user_id, title, contant";
  $query .= ") VALUES (";
  $query .= "  {$user_id}, '{$title}', '{$contant}'";
  $query .= ")";
  $result = mysqli_query($connection, $query);

  if ($result) {
    // Success
    $_SESSION["message"] = "blog post Created.";
    redirect_to("index.php");
  } else {
    // Failure
    $_SESSION["message"] = "Subject creation failed.";

    print_r(mysqli_error_list($connection));
  }
}
  
}

?>

<?php require_once('includes/layouts/header.php') ?>
<?php echo message(); ?>
<?php echo form_errors($errors); ?>
<form action="create_post.php" method="post">
  <div class="field">
    <label class="label">Post Header</label>
    <div class="control">
      <input class="input" type="text" placeholder="Post Header" name="title">
    </div>
  </div>


  <div class="field">
    <label class="label">Post Contant</label>
    <div class="control">
      <textarea class="textarea" placeholder="Post Contant" name="contant"></textarea>
    </div>
  </div>


  <div class="field is-grouped">
    <div class="control">
      <button class="button is-link" name="submit">Save</button>
    </div>
  </div>
</form>
<?php require_once('includes/layouts/footer.php') ?>