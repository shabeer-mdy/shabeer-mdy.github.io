<?php include_once("includes/session.php") ?>
<?php include_once("includes/db_connection.php")?>
<?php require_once("includes/functions.php"); ?>
<?php require_once("includes/validation_functions.php"); ?>

<?php if(!has_logged_in()){ redirect_to("index.php"); } ?>

<?php  

$post_id = (int)$_GET['id'];

$post = get_post_by_id($post_id);

if(!$post){
    $_SESSION['message'] = "somthing went to wrong";
    redirect_to("my_post.php");
}


    $query = "DELETE FROM blog_post WHERE id = {$post_id} ";
    $result = mysqli_query($connection, $query);

    if ($result) {
        // Success
        $_SESSION["message"] = "Successfully Unfollowed.";
        redirect_to("index.php");
    }else{
        
        $_SESSION["message"] = "somthing went to wrong.";
        redirect_to("show_users.php");
    }


?>